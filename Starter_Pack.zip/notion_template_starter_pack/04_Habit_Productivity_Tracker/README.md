# Habit & Productivity Tracker — Import Guide

1. In Notion, create a new page.
2. Import `Dashboard.md` as Markdown.
3. Import each `.csv` file as a separate database (CSV import).
4. Add linked database views on the dashboard page.
5. Configure property types, filters, formulas and optional relations using `Dashboard.md`.
6. Replace demo data, check every view and publish a duplicate-enabled template link.

**Note:** CSV/Markdown imports do not automatically recreate a fully designed dashboard, database relations, formulas, or Notion native views.
