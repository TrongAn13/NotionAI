# Notion Template Starter Pack — 5 Niches

Includes five English-language template starter kits, each with demo CSV databases, a dashboard Markdown page, and an import guide.

**How to import:** Open each folder and follow its README.md. Import files one at a time into Notion. Finish native layouts, formulas, database views and relations manually before selling.

**These are starter kits, not turnkey commercial-ready Notion templates.** Review and test the finished Notion pages before listing them for sale.
