# Content Creator OS

> A customizable Notion dashboard starter kit. All records are fictional examples.

## Welcome
Use this dashboard to organize your workflow. Replace sample records with your own data.

## Sections
- **Channels**
- **Ideas**
- **Production Pipeline**
- **Publishing Calendar**
- **Performance**

## Suggested views
Production Pipeline: board by Publish Status. Publishing Calendar: calendar by Publish Date. Ideas: board by Status. Performance: table sorted by Views descending.

## Optional formulas and setup
For Performance add Formula 'Engagement Rate': if(prop("Views") == 0, 0, (prop("Likes") + prop("Comments")) / prop("Views")); format as percent.

## Getting started
1. Import each CSV as a separate Notion database.
2. Change column types: dates to Date, money and numeric columns to Number, status fields to Select, and links to URL.
3. Create the views listed above.
4. Create a main Notion page with linked views of the imported databases.
5. Add relations between databases manually if desired; text columns with matching names are not actual Notion relations.
6. Delete demo records before using or distributing the template.

## License note
You may customize and sell your finished Notion template. The files do not include third-party imagery or licensed assets.
