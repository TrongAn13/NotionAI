# Personal Finance Tracker

> A customizable Notion dashboard starter kit. All records are fictional examples.

## Welcome
Use this dashboard to organize your workflow. Replace sample records with your own data.

## Sections
- **Transactions**
- **Monthly Budgets**
- **Savings Goals**
- **Accounts**

## Suggested views
Transactions: table by Date; filter Type=Expense for expense view. Monthly Budgets: board by Category. Savings Goals: gallery by Status.

## Optional formulas and setup
For Savings_Goals, add Formula property 'Progress' using: if(prop("Target Amount") == 0, 0, prop("Saved Amount") / prop("Target Amount")) ; format as percent.

## Getting started
1. Import each CSV as a separate Notion database.
2. Change column types: dates to Date, money and numeric columns to Number, status fields to Select, and links to URL.
3. Create the views listed above.
4. Create a main Notion page with linked views of the imported databases.
5. Add relations between databases manually if desired; text columns with matching names are not actual Notion relations.
6. Delete demo records before using or distributing the template.

## License note
You may customize and sell your finished Notion template. The files do not include third-party imagery or licensed assets.
