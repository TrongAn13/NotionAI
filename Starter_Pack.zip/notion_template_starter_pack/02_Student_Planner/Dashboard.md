# Student Planner

> A customizable Notion dashboard starter kit. All records are fictional examples.

## Welcome
Use this dashboard to organize your workflow. Replace sample records with your own data.

## Sections
- **Courses**
- **Assignments**
- **Exams**
- **Study Sessions**

## Suggested views
Assignments: calendar by Due Date and board by Status. Exams: calendar by Date. Courses: gallery by Semester.

## Optional formulas and setup
For Assignments add Formula 'Days Left': dateBetween(prop("Due Date"), now(), "days").

## Getting started
1. Import each CSV as a separate Notion database.
2. Change column types: dates to Date, money and numeric columns to Number, status fields to Select, and links to URL.
3. Create the views listed above.
4. Create a main Notion page with linked views of the imported databases.
5. Add relations between databases manually if desired; text columns with matching names are not actual Notion relations.
6. Delete demo records before using or distributing the template.

## License note
You may customize and sell your finished Notion template. The files do not include third-party imagery or licensed assets.
